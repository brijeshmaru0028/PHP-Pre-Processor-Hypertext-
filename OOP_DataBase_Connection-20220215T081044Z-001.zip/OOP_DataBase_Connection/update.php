<?php
$C = new mysqli("localhost","root","","bmoop");
$id = $_REQUEST['id'];
$s = "SELECT * FROM `boop` where `id`='$id' ";
$r = $C -> query($s);
$a = $r -> fetch_assoc();
?>
<html>
<head>
<style>
.gradient-custom-3 
	{
		background: #84fab0;
		background: -webkit-linear-gradient(to right, rgba(132, 250, 176, 0.5), rgba(143, 211, 244, 0.5));
		background: linear-gradient(to right, rgba(132, 250, 176, 0.5), rgba(143, 211, 244, 0.5))
	}
.gradient-custom-4 
	{
		background: #84fab0;
		background: -webkit-linear-gradient(to right, rgba(132, 250, 176, 1), rgba(143, 211, 244, 1));
		background: linear-gradient(to right, rgba(132, 250, 176, 1), rgba(143, 211, 244, 1))
	}

	
</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body
<section class="vh-100 bg-image" style="background-image: url('Abstract-blue-wave-on-transparent-background-PNG.png')";>
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px;">
            <div class="card-body p-5">
              <h1 class="text-uppercase text-center mb-5">Upadate Form</h1>

              <form action="updateac.php" method="POST">
			  <input type="hidden" name="id" id="id" value="<?php echo $id?>">

                <div class="form-outline mb-4">
                  <input type="text" id="fm" class="form-control form-control-lg" name="fm" value="<?php echo $a['fm'];?>" />
                  <label class="form-label" for="form3Example1cg">Frist Name</label>
                </div>

                <div class="form-outline mb-4">
                  <input type="text" id="lm" class="form-control form-control-lg" name="lm"  value="<?php echo $a['lm'];?>" />
                  <label class="form-label" for="form3Example3cg">Last Name</label>
                </div>

                <div class="form-outline mb-4">
                  <input type="text" id="city" class="form-control form-control-lg" name="city"  value="<?php echo $a['city'];?>"/>
                  <label class="form-label" for="form3Example4cg">City</label>
                  
                </div>

                <div class="d-flex justify-content-center">
                  <input type="submit" class="btn btn-success btn-block btn-lg gradient-custom-4 text-body" id="sbt" name="sbt" value="OK">
                </div>
				</form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>