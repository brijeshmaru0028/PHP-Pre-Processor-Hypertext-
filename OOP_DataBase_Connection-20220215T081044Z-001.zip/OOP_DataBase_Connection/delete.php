<?php
$C = new mysqli("localhost","root","","bmoop");
$id = $_REQUEST['id'];
$d = "DELETE FROM `boop` where `id`='$id'";
$C -> query($d);

header("location:show.php");
?>