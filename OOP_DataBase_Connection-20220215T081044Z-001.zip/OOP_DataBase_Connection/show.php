<?php
$C = new mysqli("localhost","root","","bmoop");
$s = "SELECT * FROM `boop`";
$r = $C -> query($s);
?>
<html>
<head>
	
</head>
<body bgcolor="lightgreen">
<table align="center" border="1px">
<tr>
       <th>Frist Name</th>
	   <th>Last Name</th>
	   <th>City</th>
	   <th>Update</th>
	   <th>Delete</th>
</tr>

<?php
     while($rs = $r -> fetch_assoc()) 
     {
?>

<tr>
    <td><?php echo $rs['fm'];?></td>	
    <td><?php echo $rs['lm'];?></td>
    <td><?php echo $rs['city'];?></td>	
	
	<?php
	$id = $rs['id'];
	?>
	
	<td><a href="update.php?id=<?php echo $id;?>">Update</a></td>
	<td><a href="delete.php?id=<?php echo $id;?>">Delete</a></td>
	
	<?php
	 }
	 ?>
</tr>
</table>
</body>
</html>
