<?php
$C = new mysqli("localhost","root","","bmoop");
$id = $_REQUEST['id'];
$fm = $_REQUEST['fm'];
$lm = $_REQUEST['lm'];
$city = $_REQUEST['city'];


$u = "UPDATE `boop` SET `fm`='$fm',`lm`='$lm',`city`='$city' WHERE `id`='$id'";
if($C -> query($u))
{
	header("location:show.php");
}
?>