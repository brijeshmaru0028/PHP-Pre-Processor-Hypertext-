<?php
$C = new mysqli("localhost","root","","bmoop");

$fm = $_REQUEST['fm'];
$lm = $_REQUEST['lm'];
$city = $_REQUEST['city'];

$i = "INSERT INTO `boop` (`fm`,`lm`,`city`)VALUES('$fm','$lm','$city')";
$C->query($i);
if ($C == TRUE)
{
	header("location:show.php");
}
?>